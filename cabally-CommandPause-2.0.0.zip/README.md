USE

allows user to spend time thinking about what to pick
NOTE:single player only currently.

recommeded mods to pair with:
ItemStatsMod
BetterUI

just throw in plug in folder or mod loader

Changelog:
2.0.0
added invicibility and invis so it should work for multiplayer. although I have not tested it no friends ;(
1.2.2
reverted all changes as it seems it stopped working.
1.2.1
Changed some stuff should work with betterui now.
1.2.0
added some changes.This should also fix the esc from menus problem. NOTE: don't use in conjunction with esc from menu's
1.1.0
added support for scrapper
1.0.1
cleaned up some code

Special thanks to SEGO

